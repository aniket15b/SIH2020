## Bhagwan Bharose

The Midday Meal Scheme is a school meal programme of the Government of India which supplies free lunches on working days for children in primary and upper primary classes in Government schools. Serving 120,000,000 children in over 1,265,000 schools and Education Guarantee Scheme centers, it is the largest of its kind in the world.

As the MidDay Meal program runs in schools across the country, continuous auditing and monitoring of the program might be challenging. Typical Auditing and Monitoring could involve:
Ensuring number of students that took meal is same number reported.
Lunch served is same as published/reported menu.
Alerting in case of discrepancy and capability to centrally see past records / proof (numbers and visual) for any school.
